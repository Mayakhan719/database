-- MySQL dump 10.13  Distrib 8.0.33, for Linux (x86_64)
--
-- Host: 127.0.0.1    Database: Airnet
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.22.04.4

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (108,'Web Expertise','<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the dynamic landscape of the digital era, an online presence is crucial for businesses and individuals alike. Website development, the intricate art of crafting and refining a virtual space, has become the cornerstone of effective communication and engagement. This blog delves into the multifaceted world of website development, shedding light on its significance and key components.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Importance of website development</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">At its core, website development involves the creation and maintenance of a website, encompassing a range of tasks from coding and designing to content creation and optimization. A well-designed website serves as a powerful tool for brand representation, offering a seamless user experience that captures and retains visitors\' attention.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Fundamental concepts of website development</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the intricate landscape of website development, a pivotal cornerstone lies in the implementation of responsive design. This foundational aspect is paramount, as it ensures the seamless functionality of a website across an expansive array of devices. In an era characterized by diverse platforms, where users effortlessly transition between smartphones, tablets, and desktops, the adaptability bestowed by responsive design becomes not merely advantageous but indispensable.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">This adaptability serves as a dynamic response to the evolving user habits and technological landscape, signifying a proactive approach to meet the expectations of a varied and discerning audience. In essence, it epitomizes the commitment to providing a consistent and optimal user experience, regardless of the device through which the website is accessed.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Vitality of UI/UX</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Furthermore, the significance of user interface (UI) and user experience (UX) stands as a paramount consideration in the meticulous craft of website development. Beyond mere aesthetics, these elements are the bedrock of a positive user experience. Intuitive navigation guides users seamlessly through the digital space, visually appealing layouts captivate attention, and swift load times contribute to a responsive and engaging encounter.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In navigating the complex interplay between technology and user interaction, prioritizing UI and UX becomes a strategic imperative. It is through these meticulous considerations, from responsive design to user-centric interfaces, that website developers weave the fabric of a digital realm that not only meets but exceeds the expectations of a diverse and discerning audience.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 16.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Conclusion</span></strong><span style=\"font-size: 12.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Website development is an intricate dance between creativity and functionality, weaving together design aesthetics and technical prowess. A well-crafted website not only reflects the essence of a brand but also serves as a dynamic gateway for meaningful interactions in the digital realm.</span></p>','assets/img/blogs/655f06f3c8073.jpg','2023-11-23 06:56:56','2023-11-23 08:01:55'),(109,'Exploring Android Development','<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Innovation of Android Development</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the ever-evolving realm of technology, Android development stands as a beacon of innovation, powering the vast ecosystem of mobile apps. This blog explores the intricacies of Android development, shedding light on its significance and key considerations.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Android, being an open-source platform, provides developers with a versatile canvas to create applications tailored to diverse user needs. The blog will delve into the fundamentals of Android development, from the Android Studio environment to the Java or Kotlin programming languages that serve as the building blocks for crafting robust mobile applications.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">UX/UI aspects of Android</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">User experience (UX) and user interface (UI) design are pivotal aspects discussed in the blog, emphasizing their role in creating visually appealing and user-friendly mobile apps. Additionally, it will touch upon the importance of optimizing apps for performance, ensuring they run seamlessly on a variety of devices.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">As the mobile app landscape continues to burgeon, understanding the nuances of Android development becomes paramount. This blog aims to demystify the process, offering insights into the tools, techniques, and best practices that empower developers to navigate and excel in the dynamic world of mobile app creation.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Moreover, the blog highlights the crucial significance of user experience (UX) and user interface (UI) design, accentuating their contribution to crafting visually appealing and user-friendly mobile apps. Expanding its focus, the blog delves into the critical realm of optimizing app performance, guaranteeing seamless operation across a diverse spectrum of devices.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Equipped with the insights distilled from this thorough investigation, developers gain the empowerment to confidently traverse the dynamic terrain of mobile app creation. Their newfound knowledge positions them to excel with confidence, actively participating in and influencing the continual evolution of technology.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Conclusion</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Android development stands at the forefront of technological innovation, driving the expansive landscape of mobile apps. As an open-source platform, Android provides developers with a flexible canvas to craft applications tailored to diverse user needs. This blog has explored the fundamental aspects of Android development, spanning from the Android Studio environment to the Java or Kotlin programming languages.</span></p>','assets/img/blogs/655f06faed06d.jpg','2023-11-23 07:24:40','2023-11-23 08:02:02'),(110,'AI Revolutionized','<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the rapidly evolving landscape of technology, Artificial Intelligence (AI) emerges as a formidable force, profoundly transforming the fabric of our existence. This blog embarks on a comprehensive exploration into the far-reaching impact of AI, dissecting its applications, contemplating its implications, and envisioning the exhilarating possibilities it holds for the future.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Significance of AI</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">At its essence, AI signifies the development of computer systems endowed with the capability to perform tasks traditionally within the domain of human intelligence. This encompasses a vast spectrum of technologies, from the intricacies of natural language processing to the sophistication of machine learning. The overarching goal is to amplify efficiency, productivity, and innovation across a myriad of industries.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Role of AI in routine tasks</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">One striking arena where AI flexes its prowess is in healthcare. Here, it contributes to diagnostics, facilitates the advent of personalized medicine, and employs predictive analytics to revolutionize patient care. Similarly, in the financial sector, AI algorithms meticulously scrutinize immense datasets, optimizing investment strategies, and acting as vigilant watchdogs to detect and thwart fraudulent activities. Additionally, the advent of AI-driven chatbots heralds a paradigm shift in customer service, delivering instantaneous and tailor-made interactions.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Navigating the epoch of AI beckons the imperative consideration of ethical dimensions and responsible AI development. This blog delves into these crucial topics, underscoring the need to address biases in AI algorithms and advocating for transparency to ensure the ethical deployment of AI technologies.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In essence, this discourse is a celebration of the present accomplishments of AI, contrasted &nbsp;</span><span style=\"font-size: 18.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">with contemplation on the boundless possibilities it unfurls. Whether enhancing our daily lives or propelling entire industries toward unprecedented innovation, AI serves as an unwavering beacon of progress. In shaping a future where intelligent technologies propel us into new frontiers, AI stands not just as a technology but as a catalyst for transformative evolution.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Versatility of AI</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">The versatility of AI, encompassing natural language processing and machine learning, underscores its role as a catalyst for efficiency, productivity, and innovation across diverse industries. In healthcare, it propels advancements in diagnostics and personalized medicine, while in finance, AI algorithms optimize strategies and safeguard against fraudulent activities. The advent of AI-driven chatbots further redefines customer service, offering instant and personalized interactions.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\">&nbsp;</p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: #0f0f0f;\">Conclusion</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: #0f0f0f;\">In conclusion, the dynamic landscape of Artificial Intelligence (AI) unfolds as a powerful force shaping the course of our technological journey. Through the lens of this blog, we have traversed the breadth of AI\'s impact, from its fundamental definition as a creator of intelligent computer systems to its far-reaching applications in healthcare, finance, and customer service.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif; color: #0f0f0f;\">&nbsp;</span></p>','assets/img/blogs/655f0702b6e5f.jpg','2023-11-23 07:28:03','2023-11-23 08:02:10'),(111,'The Core of SQA','<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the domain</span><span style=\"font-size: 18.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">of software development, the beacon guiding success is Software Quality Assurance (SQA). This blog unravels the crucial role SQA plays in delivering software excellence, emphasizing its impact on product reliability and customer satisfaction.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 16.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Significance</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Software Quality Assurance is the meticulous process of ensuring that the software meets the specified standards and requirements throughout its development life cycle. Its significance lies in mitigating risks, enhancing efficiency, and ultimately delivering a product that not only meets but exceeds user expectations.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">At its core, SQA involves comprehensive testing, rigorous code reviews, and adherence to best practices. These measures not only identify and rectify defects but also contribute to the overall improvement of the software development process.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">The essence of SQA extends beyond bug detection; it encompasses the establishment of robust processes, adherence to industry standards, and the cultivation of a culture of continuous improvement. This proactive approach not only assures the quality of the software but also instills confidence in stakeholders and end-users alike.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">As organizations recognize the pivotal role of SQA, they embrace a commitment to delivering software products of the highest caliber. In a digital landscape where reliability and performance are non-negotiable, Software Quality Assurance emerges as the cornerstone for building software solutions that stand the test of time.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\">&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Elevating Software Excellence</strong></span></p>\r\n<p><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In the dynamic landscape of software development, the significance of Software Quality Assurance (SQA) extends far beyond bug detection. SQA is the bedrock of ensuring that software not only meets but consistently exceeds the stipulated standards and requirements. Let\'s delve deeper into the multifaceted dimensions of SQA and its integral role in delivering robust and reliable software solutions.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Moreover, SQA is synonymous with adherence to industry standards and the establishment of robust processes. By aligning with recognized benchmarks and implementing systematic procedures, SQA becomes a guiding force in achieving consistency, reliability, and scalability in software applications.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">As organizations increasingly recognize the critical role of SQA, there is a growing commitment to fostering a culture of continuous improvement. This involves learning from each testing phase, refining processes, and integrating feedback loops to ensure that every iteration of software is an enhancement over the previous one.</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">&nbsp;</span></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><strong><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">Conclusion</span></strong></p>\r\n<p style=\"margin: 0in 0in 8pt; line-height: 107%; font-size: 11pt; font-family: Calibri, sans-serif;\"><span style=\"font-size: 14.0pt; line-height: 107%; font-family: \'Times New Roman\', serif;\">In conclusion, Software Quality Assurance emerges not just as a phase in development but as a strategic imperative for organizations aspiring to deliver software solutions that stand the test of time. With SQA as the guiding compass, software development becomes a journey of constant refinement, assuring not only the quality of the product but also the satisfaction of end-users and stakeholders alike.</span></p>','assets/img/blogs/655f070d89008.jpg','2023-11-23 07:37:34','2023-11-23 08:02:21'),(112,'Graphic Design: Art & Impact','<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">In the dynamic world of digital communication, graphic design stands as a powerful medium, shaping our visual experiences and conveying messages with artistic flair. This blog explores the multifaceted realm of graphic design, delving into its significance, principles, and the transformative impact it holds across various industries.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Graphic design is more than just the arrangement of colors and images; it\'s a storytelling tool that communicates ideas, emotions, and brand identities. From logos that encapsulate a company\'s ethos to engaging social media graphics, the applications of graphic design are diverse and impactful.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">At its essence, graphic design is guided by fundamental principles such as balance, contrast, and harmony. Understanding the interplay of these elements empowers designers to create visually compelling and aesthetically pleasing compositions. The blog will unravel these principles, providing insights into how they contribute to the effectiveness of graphic design.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Moreover, in the digital era, where attention spans are fleeting, the importance of captivating visual content cannot be overstated. The blog will explore how graphic design plays a pivotal role in capturing audience attention, fostering engagement, and leaving a lasting impression.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Join us on a visual journey as we delve into the world of graphic design, celebrating its artistic nuances, exploring its practical applications, and recognizing its role as a transformative force in the ever-evolving landscape of digital communication.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">Delving into the intricate world of graphic design unveils a realm where creativity converges with strategic principles. The essence of graphic design lies in the mastery of fundamental principles such as balance, contrast, and harmony. These serve as the building blocks, empowering designers to orchestrate visually compelling and aesthetically pleasing compositions that resonate with audiences.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Conclusion</strong></span></p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">The realm of graphic design emerges as a dynamic fusion of creativity and strategic principles. Guided by fundamental elements such as balance, contrast, and harmony, designers wield the power to craft visually captivating compositions that transcend aesthetics. These principles serve as the cornerstone of effective design, enabling the communication of messages with precision and impact.</span></p>','assets/img/blogs/655f07174025d.jpg','2023-11-23 07:41:22','2023-11-23 08:02:31'),(113,'Exploring a Software House','<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">The realm of a software house is a dynamic fusion of creativity, precision, and collaborative ingenuity. This blog invites you to step into the heart of a software house, exploring the nuances that define its culture, the craftsmanship that goes into code development, and the collaborative spirit that fuels innovation.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">At the core of every software house is a dedicated team of professionals, each contributing their expertise to create digital solutions that transcend expectations. From software architects shaping the blueprint to developers translating ideas into lines of code, the journey within a software house is a symphony of skillsets harmonizing towards a common goal.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Methodologies of Software Development</strong></span></p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">This blog delves into the methodologies that drive software development within a software house. From Agile to DevOps, it unravels the frameworks that optimize efficiency, foster adaptability, and ensure seamless collaboration across diverse teams. Understanding these methodologies is not just a peek into the operational framework but an exploration of the ethos that defines the software house culture.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">The craftsmanship of code takes center stage in this narrative. Every line written is a manifestation of precision, innovation, and problem-solving. The blog explores how a commitment to coding excellence defines the character of a software house, impacting the quality and functionality of the end products.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Collaboration and Mutual Evolution</strong></span></p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">In the ever-evolving landscape of software development, the pulse of a thriving software house is its collaborative heartbeat. This blog embarks on an exploration of how cutting-edge communication tools and innovative project management platforms synergize, fostering an environment where teamwork seamlessly breathes life into groundbreaking ideas. It delves into the intricacies of this collaborative spirit, tracing its transformative journey from conceptualization to the realization of tangible software solutions.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">As the digital workspace becomes the canvas for inventive minds, the blog sheds light on the pivotal role of effective communication. It not only outlines the latest tools shaping this communication landscape but also delves into the strategic significance of fostering a culture where ideas flow freely and collaboration becomes an inherent part of the development process.</span></p>\r\n<p>&nbsp;</p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\"><strong>Conclusion</strong></span></p>\r\n<p><span style=\"font-family: \'times new roman\', times, serif; font-size: 14pt;\">In conclusion, the journey through the intricacies of collaborative transformation unveils a dynamic narrative of collective growth and innovation within the digital workspace. As we explored the synergy of ideas, communication tools, and project management platforms, it became evident that the collaborative spirit is the driving force behind turning concepts into tangible software solutions.</span></p>','assets/img/blogs/655f07205a9e4.jpg','2023-11-23 07:45:34','2023-11-23 08:02:40');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (15,'test','test@gmail.com','Testing','this is just a test message','user','2023-12-08 05:52:25','2023-12-08 05:52:25'),(16,'test','test@gmail.com','Testing','testing passed','admin','2023-12-08 05:52:47','2023-12-08 05:52:47');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `members` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=116 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `members`
--

LOCK TABLES `members` WRITE;
/*!40000 ALTER TABLE `members` DISABLE KEYS */;
INSERT INTO `members` VALUES (112,'Muhammad Aman','Project Manager','assets/img/member/655f0493c180d.png','2023-11-23 07:51:47','2023-11-23 07:51:47'),(113,'Mohsin Ali','Graphic Designer','assets/img/member/655f049da597e.png','2023-11-23 07:51:57','2023-11-23 07:51:57'),(114,'Muhammad Huraira','SQA Engineer','assets/img/member/655f04bd0999f.png','2023-11-23 07:52:29','2023-11-23 07:52:29'),(115,'Muhammad Shoaib','Web Developer','assets/img/member/655f04d4dcb67.png','2023-11-23 07:52:52','2023-11-23 07:52:52');
/*!40000 ALTER TABLE `members` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_reset_tokens_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',1),(4,'2019_12_14_000001_create_personal_access_tokens_table',1),(5,'2023_11_06_121340_create_contact_table',1),(6,'2014_10_12_100000_create_password_resets_table',2),(7,'2023_11_08_052811_project_models',2),(8,'2023_11_08_115555_create_team_member',2),(9,'2023_11_14_115434_create_contact_table',2),(10,'2023_11_22_062850_create_blogs_table',3);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `thumbnail` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting`
--

DROP TABLE IF EXISTS `setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `setting` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `type` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting`
--

LOCK TABLES `setting` WRITE;
/*!40000 ALTER TABLE `setting` DISABLE KEYS */;
INSERT INTO `setting` VALUES (1,'logo','{\"logo\":\"assets\\/images\\/logos\\/1701175007_1701156435_final-logo.png\",\"favicon\":\"assets\\/images\\/logos\\/1701175012_1701156442_final-logo.png\"}','2023-11-27 01:02:48','2023-11-28 12:36:52'),(2,'about_us','We\'ve helped many users with our top-rated apps, websites, and custom software. Our global mission is to deliver high-quality applications on the Play Store and provide custom app, website, API, and hybrid app services to users worldwide.','2023-11-27 03:14:03','2023-11-27 04:17:37');
/*!40000 ALTER TABLE `setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','admin@mobipixels.com',NULL,'$2y$10$tNatIi/R5O.hQ7NOYcKYS.sD/4.L3uM4QGzr/o2Ph8oOvLIaEh/K.',NULL,'2023-11-22 06:13:25','2023-11-22 06:13:25');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-04  3:15:05
